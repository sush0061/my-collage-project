# Ayurvedic_Drug_Recommendation_System
Ayurvedic Drug Recommendation System is a smart web app that suggests suitable  Ayurvedic treatments based on user symptoms and age. It offers quick guidance in early-stage or emergency conditions when doctors may not be immediately available.
